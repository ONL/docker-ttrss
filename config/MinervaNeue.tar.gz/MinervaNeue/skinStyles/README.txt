If a module introduced by MobileFrontend has Minerva specific styles they are added here and applied
as part of ResourceModuleSkinStyles.
