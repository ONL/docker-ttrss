Subfolders refer to "features" of the mobile codebase.

Code in this folder should be considered reusable and generic.
